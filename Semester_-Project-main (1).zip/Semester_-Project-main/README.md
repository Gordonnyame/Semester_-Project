NAME:NYAME GORDON



INDEX NUMBER:UEB3226022


IT (D CLASS)

Inventory System

This project is designed to create an inventory system in C++ using objectoriented programming. The system will enable the user to store and track 
information about products, including their quantity, price, and other details. The 
technologies used for this project include C++ programming language, and 
database management systems such as MySQL.
